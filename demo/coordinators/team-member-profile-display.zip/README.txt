A Pen created at CodePen.io. You can find this one at https://codepen.io/mauritiusdsilva/pen/NqLrxO.

 Created this team member profile display section for a single page HTML5 responsive template, based on Bootstrap 3, the theme is now available for FREE download.

Live demo: http://bit.ly/ht_preview
Free Download: http://bit.ly/hh5_template 